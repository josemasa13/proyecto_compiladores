# Avance 3 de proyecto Par++
#### José Alberto Marcial Sánchez
#### Eduardo André Martínez Romero

## Avance hasta el momento

- Para esta entrega nos pusimos al corriente hasta los puntos a cubrir de la entrega número 4 en la que se incluyen los siguientes puntos:
- Generacion de código de estatutos condicionales : 
- Generacion de código de estatutos condicionales : decisiones
- Generación de código de las funciones
- Pequeños avances sobre el mapa de memoria de ejecución para la MV
