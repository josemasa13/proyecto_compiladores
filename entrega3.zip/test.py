def p_vars(p):
    '''VAR vars2'''

def p_vars2(p):
    '''ID vars3'''

def p_vars3(p):
    '''COLON tipo SEMICOLON vars2
    | COMMA vars2'''