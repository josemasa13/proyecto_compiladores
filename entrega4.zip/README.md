# Avance 3 de proyecto Par++
#### José Alberto Marcial Sánchez
#### Eduardo André Martínez Romero

## Avance hasta el momento

- Se corrigieron algunos errores con los puntos neurálgicos de la entrega pasada.
- Terminamos el cubo semántico 
- Se agregaron funciones de generación de código intermedio para las expresiones aritméticas, asignación y lectura